from typing import Dict, List
import logging
from collections import defaultdict
from app.models.document import Document, InvertedIndexEntry

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class InvertedIndex:
    """Inverted index implementation for fast text search."""

    def __init__(self):
        """Initialize the inverted index."""
        self.index: Dict[str, Dict[str, List[int]]] = defaultdict(
            lambda: defaultdict(list)
        )
        self.bigram_index: Dict[str, Dict[str, List[int]]] = defaultdict(
            lambda: defaultdict(list)
        )

    def add_document(self, document: Document) -> None:
        tokens = (
            document.get_tokens()
        )  # Assumes get_tokens() is defined in your Document class
        logger.debug(f"Tokens for {document.url}: {tokens[:20]}...")

        for position, token in enumerate(tokens):
            if token:
                self.index[token][document.url].append(position)

        for position in range(len(tokens) - 1):
            if tokens[position] and tokens[position + 1]:
                bigram = f"{tokens[position]} {tokens[position + 1]}"
                self.bigram_index[bigram][document.url].append(position)

    def build_index(self, documents: Dict[str, Document]) -> None:
        logger.info(f"Building inverted index for {len(documents)} documents...")
        self.index.clear()
        self.bigram_index.clear()

        for url, document in documents.items():
            self.add_document(document)

        logger.info(
            f"Inverted index built with {len(self.index)} terms and {len(self.bigram_index)} bigrams."
        )

    def search(self, query: str) -> Dict[str, float]:
        query = query.lower().strip()
        tokens = query.split()

        if len(tokens) == 1:
            term = tokens[0]
            if term in self.index:
                return {
                    url: len(positions) for url, positions in self.index[term].items()
                }
            return {}

        bigrams = [f"{tokens[i]} {tokens[i + 1]}" for i in range(len(tokens) - 1)]
        matching_docs = None

        for bigram in bigrams:
            if bigram in self.bigram_index:
                docs = set(self.bigram_index[bigram].keys())
                matching_docs = docs if matching_docs is None else matching_docs & docs
            else:
                return {}

        if not matching_docs:
            return {}

        results = {}
        for url in matching_docs:
            min_freq = float("inf")
            for bigram in bigrams:
                freq = len(self.bigram_index[bigram][url])
                min_freq = min(min_freq, freq)
            results[url] = min_freq

        return results

    def to_dict(self) -> Dict[str, InvertedIndexEntry]:
        result = {}
        for term, docs in self.index.items():
            result[term] = InvertedIndexEntry(term=term, documents=dict(docs))
        for bigram, docs in self.bigram_index.items():
            result[f"_bigram_{bigram}"] = InvertedIndexEntry(
                term=bigram, documents=dict(docs)
            )
        return result

    def from_dict(self, index_dict: Dict[str, InvertedIndexEntry]) -> None:
        self.index.clear()
        self.bigram_index.clear()

        for term, entry in index_dict.items():
            if term.startswith("_bigram_"):
                bigram = term[len("_bigram_") :]
                for url, positions in entry.documents.items():
                    self.bigram_index[bigram][url] = positions
            else:
                for url, positions in entry.documents.items():
                    self.index[term][url] = positions
