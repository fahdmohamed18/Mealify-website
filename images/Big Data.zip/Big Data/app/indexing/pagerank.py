import networkx as nx
import logging
from typing import Dict, List, Set
from app.models.document import Document, WebGraph

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PageRank:
    """PageRank algorithm implementation."""

    def __init__(
        self,
        damping_factor: float = 0.85,
        max_iterations: int = 100,
        tolerance: float = 1.0e-6,
    ):
        self.damping_factor = damping_factor
        self.max_iterations = max_iterations
        self.tolerance = tolerance
        self.scores: Dict[str, float] = {}
        self.graph: nx.DiGraph = nx.DiGraph()

    def build_graph(self, documents: Dict[str, Document]) -> WebGraph:
        logger.info(f"Building web graph from {len(documents)} documents...")
        self.graph.clear()

        for url in documents.keys():
            self.graph.add_node(url)

        for url, document in documents.items():
            for outlink in document.outgoing_links:
                if outlink in documents:
                    self.graph.add_edge(url, outlink)
                    logger.debug(f"Added edge from {url} to {outlink}")

        logger.info(
            f"Web graph built with {self.graph.number_of_nodes()} nodes and {self.graph.number_of_edges()} edges."
        )

        nodes = set(self.graph.nodes())
        edges = {node: list(self.graph.successors(node)) for node in self.graph.nodes()}

        return WebGraph(nodes=nodes, edges=edges)

    def load_graph(self, web_graph: WebGraph) -> None:
        self.graph.clear()
        for node in web_graph.nodes:
            self.graph.add_node(node)
        for source, targets in web_graph.edges.items():
            for target in targets:
                self.graph.add_edge(source, target)

        logger.info(
            f"Loaded web graph with {self.graph.number_of_nodes()} nodes and {self.graph.number_of_edges()} edges."
        )

    def calculate_pagerank(self) -> Dict[str, float]:
        logger.info("Calculating PageRank scores...")
        if self.graph.number_of_nodes() == 0:
            logger.warning("Graph is empty. No PageRank scores calculated.")
            return {}

        try:
            self.scores = nx.pagerank(
                self.graph,
                alpha=self.damping_factor,
                max_iter=self.max_iterations,
                tol=self.tolerance,
            )
            logger.info(f"PageRank calculation completed for {len(self.scores)} nodes.")
            return self.scores
        except nx.PowerIterationFailedConvergence:
            logger.warning(
                "PageRank calculation failed to converge. Using simplified method."
            )
            return self._calculate_pagerank_simplified()

    def _calculate_pagerank_simplified(self) -> Dict[str, float]:
        n = self.graph.number_of_nodes()
        if n == 0:
            return {}

        scores = {node: 1.0 / n for node in self.graph.nodes()}

        for _ in range(min(10, self.max_iterations)):
            new_scores = {
                node: (1 - self.damping_factor) / n for node in self.graph.nodes()
            }

            for node in self.graph.nodes():
                outlinks = list(self.graph.successors(node))
                if outlinks:
                    for outlink in outlinks:
                        new_scores[outlink] += (
                            self.damping_factor * scores[node] / len(outlinks)
                        )
                else:
                    for other_node in self.graph.nodes():
                        new_scores[other_node] += self.damping_factor * scores[node] / n

            scores = new_scores

        total = sum(scores.values())
        if total > 0:
            scores = {node: score / total for node, score in scores.items()}

        self.scores = scores
        return scores

    def get_ranked_urls(self) -> List[str]:
        if not self.scores:
            logger.warning("PageRank scores not calculated. Returning empty list.")
            return []
        return sorted(
            self.scores.keys(), key=lambda url: self.scores[url], reverse=True
        )

    def get_score(self, url: str) -> float:
        return self.scores.get(url, 0.0)
