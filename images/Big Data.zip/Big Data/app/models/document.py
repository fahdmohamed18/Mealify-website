from pydantic import BaseModel
from typing import Dict, List, Optional, Set
from datetime import datetime


class Document(BaseModel):
    """Document model representing a web page."""

    url: str
    title: str
    content: str
    content_text: str
    last_crawled: datetime = datetime.now()
    outgoing_links: List[str] = []

    def get_tokens(self) -> List[str]:
        """Tokenize the content text into words."""
        # Simple tokenization by splitting on whitespace and removing punctuation
        # In a real-world scenario, you'd want more sophisticated tokenization
        tokens = []
        for word in self.content_text.lower().split():
            # Remove punctuation and normalize
            word = "".join(c for c in word if c.isalnum())
            if word:
                tokens.append(word)
        return tokens

    def get_bigrams(self) -> List[str]:
        """Get bigrams (consecutive word pairs) from the content."""
        tokens = self.get_tokens()
        return [f"{tokens[i]} {tokens[i+1]}" for i in range(len(tokens) - 1)]


class SearchResult(BaseModel):
    """Model for search results."""

    url: str
    title: str
    content_preview: str
    score: float
    summary: Optional[str] = None


class InvertedIndexEntry(BaseModel):
    """Entry in the inverted index."""

    term: str
    documents: Dict[str, List[int]]  # url -> positions in document


class WebGraph(BaseModel):
    """Model representing the web graph for PageRank."""

    nodes: Set[str]  # Set of URLs
    edges: Dict[str, List[str]]  # URL -> outgoing links

    class Config:
        arbitrary_types_allowed = True
