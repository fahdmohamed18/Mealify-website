import json
import os
import logging
from typing import Dict, List, Optional
import pickle
from datetime import datetime
from pyarrow import hdfs
from app.models.document import Document, InvertedIndexEntry, WebGraph
import re  # To support the sanitize function fix

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# For local development/testing, we'll use a local file system
# In production, this would connect to an actual HDFS cluster
USE_LOCAL_FS = os.environ.get("USE_LOCAL_FS", "true").lower() == "true"


class HDFSStorage:
    """Storage class that handles saving and loading data to/from HDFS."""

    def __init__(self, host: str = "default", port: int = 0, user: str = "hdfs"):
        """
        Initialize HDFS storage.

        For local development/testing, this will use a local directory.
        In production, this would connect to an actual HDFS cluster.

        Args:
            host: HDFS host
            port: HDFS port
            user: HDFS user
        """
        self.host = host
        self.port = port
        self.user = user

        # Base paths
        self.docs_path = "search_engine/documents"
        self.index_path = "search_engine/index"
        self.graph_path = "search_engine/graph"

        if USE_LOCAL_FS:
            # Use local filesystem for development/testing
            self.base_dir = os.path.join(
                os.path.dirname(os.path.dirname(__file__)), "data"
            )
            os.makedirs(os.path.join(self.base_dir, self.docs_path), exist_ok=True)
            os.makedirs(os.path.join(self.base_dir, self.index_path), exist_ok=True)
            os.makedirs(os.path.join(self.base_dir, self.graph_path), exist_ok=True)
        else:
            # Connect to HDFS
            self.fs = hdfs.connect(host=self.host, port=self.port, user=self.user)

            # Ensure directories exist
            self._ensure_dir(self.docs_path)
            self._ensure_dir(self.index_path)
            self._ensure_dir(self.graph_path)

    def _ensure_dir(self, path: str) -> None:
        """Ensure directory exists in HDFS."""
        if USE_LOCAL_FS:
            os.makedirs(os.path.join(self.base_dir, path), exist_ok=True)
        else:
            if not self.fs.exists(path):
                self.fs.mkdir(path)

    def _sanitize_filename(self, url: str) -> str:
        """Sanitize URL to use as filename."""
        return re.sub(
            r"[^a-zA-Z0-9_]", "_", url
        )  # Using regular expression to replace problematic characters

    def save_document(self, document: Document) -> None:
        """Save a document to storage."""
        filename = self._sanitize_filename(document.url)
        file_path = f"{self.docs_path}/{filename}.json"

        logger.info(f"Saving document: {document.url} as {file_path}")  # Debug log

        # Convert to dict and serialize
        doc_dict = document.dict()
        doc_dict["last_crawled"] = doc_dict["last_crawled"].isoformat()

        if USE_LOCAL_FS:
            with open(os.path.join(self.base_dir, file_path), "w") as f:
                json.dump(doc_dict, f)
                logger.info(f"Document saved to {file_path}")  # Debug log
        else:
            with self.fs.open(file_path, "wb") as f:
                f.write(json.dumps(doc_dict).encode("utf-8"))
                logger.info(f"Document saved to HDFS: {file_path}")  # Debug log

    def load_document(self, url: str) -> Optional[Document]:
        """Load a document from storage."""
        filename = self._sanitize_filename(url)
        file_path = f"{self.docs_path}/{filename}.json"

        try:
            if USE_LOCAL_FS:
                if not os.path.exists(os.path.join(self.base_dir, file_path)):
                    return None

                with open(os.path.join(self.base_dir, file_path), "r") as f:
                    doc_dict = json.load(f)
            else:
                if not self.fs.exists(file_path):
                    return None

                with self.fs.open(file_path, "rb") as f:
                    doc_dict = json.loads(f.read().decode("utf-8"))

            # Parse datetime
            doc_dict["last_crawled"] = datetime.fromisoformat(doc_dict["last_crawled"])

            return Document(**doc_dict)
        except Exception as e:
            logger.error(f"Error loading document {url}: {str(e)}")
            return None

    def save_documents(self, documents: Dict[str, Document]) -> None:
        """Save multiple documents to storage."""
        for url, document in documents.items():
            self.save_document(document)

    def load_all_documents(self) -> Dict[str, Document]:
        """Load all documents from storage."""
        documents = {}

        if USE_LOCAL_FS:
            docs_dir = os.path.join(self.base_dir, self.docs_path)
            if not os.path.exists(docs_dir):
                return {}

            for filename in os.listdir(docs_dir):
                if filename.endswith(".json"):
                    file_path = os.path.join(docs_dir, filename)
                    with open(file_path, "r") as f:
                        doc_dict = json.load(f)

                    # Parse datetime
                    doc_dict["last_crawled"] = datetime.fromisoformat(
                        doc_dict["last_crawled"]
                    )

                    document = Document(**doc_dict)
                    documents[document.url] = document
        else:
            if not self.fs.exists(self.docs_path):
                return {}

            for file_info in self.fs.ls(self.docs_path):
                if file_info.endswith(".json"):
                    with self.fs.open(file_info, "rb") as f:
                        doc_dict = json.loads(f.read().decode("utf-8"))

                    # Parse datetime
                    doc_dict["last_crawled"] = datetime.fromisoformat(
                        doc_dict["last_crawled"]
                    )

                    document = Document(**doc_dict)
                    documents[document.url] = document

        return documents

    def save_inverted_index(self, index: Dict[str, InvertedIndexEntry]) -> None:
        """Save inverted index to storage."""
        file_path = f"{self.index_path}/inverted_index.pickle"

        if USE_LOCAL_FS:
            with open(os.path.join(self.base_dir, file_path), "wb") as f:
                pickle.dump(index, f)
        else:
            with self.fs.open(file_path, "wb") as f:
                pickle.dump(index, f)

    def load_inverted_index(self) -> Dict[str, InvertedIndexEntry]:
        """Load inverted index from storage."""
        file_path = f"{self.index_path}/inverted_index.pickle"

        try:
            if USE_LOCAL_FS:
                if not os.path.exists(os.path.join(self.base_dir, file_path)):
                    return {}

                with open(os.path.join(self.base_dir, file_path), "rb") as f:
                    return pickle.load(f)
            else:
                if not self.fs.exists(file_path):
                    return {}

                with self.fs.open(file_path, "rb") as f:
                    return pickle.load(f)
        except Exception as e:
            logger.error(f"Error loading inverted index: {str(e)}")
            return {}

    def save_web_graph(self, graph: WebGraph) -> None:
        """Save web graph to storage."""
        file_path = f"{self.graph_path}/web_graph.pickle"

        if USE_LOCAL_FS:
            with open(os.path.join(self.base_dir, file_path), "wb") as f:
                pickle.dump(graph, f)
        else:
            with self.fs.open(file_path, "wb") as f:
                pickle.dump(graph, f)

    def load_web_graph(self) -> Optional[WebGraph]:
        """Load web graph from storage."""
        file_path = f"{self.graph_path}/web_graph.pickle"

        try:
            if USE_LOCAL_FS:
                if not os.path.exists(os.path.join(self.base_dir, file_path)):
                    return None

                with open(os.path.join(self.base_dir, file_path), "rb") as f:
                    return pickle.load(f)
            else:
                if not self.fs.exists(file_path):
                    return None

                with self.fs.open(file_path, "rb") as f:
                    return pickle.load(f)
        except Exception as e:
            logger.error(f"Error loading web graph: {str(e)}")
            return None

    def save_pagerank_scores(self, scores: Dict[str, float]) -> None:
        """Save PageRank scores to storage."""
        file_path = f"{self.graph_path}/pagerank_scores.json"

        if USE_LOCAL_FS:
            with open(os.path.join(self.base_dir, file_path), "w") as f:
                json.dump(scores, f)
        else:
            with self.fs.open(file_path, "wb") as f:
                f.write(json.dumps(scores).encode("utf-8"))

    def load_pagerank_scores(self) -> Dict[str, float]:
        """Load PageRank scores from storage."""
        file_path = f"{self.graph_path}/pagerank_scores.json"

        try:
            if USE_LOCAL_FS:
                if not os.path.exists(os.path.join(self.base_dir, file_path)):
                    return {}

                with open(os.path.join(self.base_dir, file_path), "r") as f:
                    return json.load(f)
            else:
                if not self.fs.exists(file_path):
                    return {}

                with self.fs.open(file_path, "rb") as f:
                    return json.loads(f.read().decode("utf-8"))
        except Exception as e:
            logger.error(f"Error loading PageRank scores: {str(e)}")
            return {}
