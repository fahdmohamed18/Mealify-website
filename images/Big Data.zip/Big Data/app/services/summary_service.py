import logging
from typing import Dict, List, Optional
import os
import asyncio
import re
import random
from groq import Groq
from concurrent.futures import ThreadPoolExecutor

from app.models.document import Document, SearchResult

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Groq client
client = Groq(api_key=os.environ.get("GROQ_API_KEY", "groq-api-key"))


class SummaryService:
    """Service that handles content summarization using Groq with random sentence sampling."""

    def __init__(self, max_workers: int = 3, num_sentences: int = 10):
        """
        Initialize the summary service.

        Args:
            max_workers: Maximum number of concurrent requests
            num_sentences: Number of random sentences to sample for summarization
        """
        self.max_workers = max_workers
        self.num_sentences = num_sentences
        self.executor = ThreadPoolExecutor(max_workers=max_workers)

    async def summarize_documents(
        self, documents: List[Document], max_length: int = 5
    ) -> Dict[str, str]:
        """(Unchanged from original, keep the same implementation)"""

    def _sample_sentences(self, text: str) -> str:
        """
        Extract random sentences from text content.

        Args:
            text: Input text content

        Returns:
            String containing sampled sentences
        """
        # Split text into sentences using basic regex
        sentences = re.split(r"(?<=[.!?]) +", text)
        sentences = [s.strip() for s in sentences if s.strip()]

        # Select random sentences
        if len(sentences) > self.num_sentences:
            selected = random.sample(sentences, self.num_sentences)
        else:
            selected = sentences  # Use all if not enough sentences

        # Fallback if no sentences detected
        if not selected:
            return text[:500]  # Return first 250 characters

        return " ".join(selected)

    def summarize_document(self, document: Document) -> Optional[str]:
        """
        Summarize a document using random sentence samples and Groq.

        Args:
            document: Document to summarize

        Returns:
            Summary text or None if failed
        """
        try:
            # Extract random sentences from content
            content_sample = self._sample_sentences(document.content_text)

            prompt = f"""
            You must detect the language of the content excerpts below. 
            If the content is in Arabic, generate the summary in Arabic. 
            If the content is in English, generate the summary in English.
            Do NOT translate — summarize in the same language as the content.

            Create a concise 3-4 sentence summary focusing on the main subject and key information. 
            Do not mention that it's based on excerpts. Only output the summary text.

            URL: {document.url}
            Title: {document.title}

            Content Excerpts:
            {content_sample}

            Concise Summary:
            """

            response = client.chat.completions.create(
                model="mistral-saba-24b",  # Fast Groq model
                messages=[
                    {
                        "role": "system",
                        "content": "You are a concise content summarizer.",
                    },
                    {"role": "user", "content": prompt},
                ],
                max_tokens=100,
                temperature=0.2,
                top_p=0.9,
            )

            return response.choices[0].message.content.strip()

        except Exception as e:
            logger.error(f"Error summarizing {document.url}: {str(e)}")
            return None

    async def enhance_search_results(
        self, results: List[SearchResult], max_summaries: int = 5
    ) -> List[SearchResult]:
        """(Unchanged from original, keep the same implementation)"""
