import logging
from typing import Dict, List, Tuple, Optional
from concurrent.futures import ThreadPoolExecutor
import re

from app.models.document import Document, SearchResult
from app.indexing.inverted_index import InvertedIndex
from app.indexing.pagerank import PageRank
from app.storage.hdfs_storage import HDFSStorage

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SearchService:
    """Service that handles search functionality."""

    def __init__(self, storage: HDFSStorage):
        """
        Initialize the search service.

        Args:
            storage: Storage instance to use
        """
        self.storage = storage
        self.documents: Dict[str, Document] = {}
        self.inverted_index = InvertedIndex()
        self.pagerank = PageRank()
        self.pagerank_scores: Dict[str, float] = {}

        # Load data if available
        self._load_data()

    def _load_data(self) -> None:
        """Load data from storage."""
        # Load documents
        self.documents = self.storage.load_all_documents()
        if self.documents:
            logger.info(f"Loaded {len(self.documents)} documents from storage.")

        # Load inverted index
        index_dict = self.storage.load_inverted_index()
        if index_dict:
            self.inverted_index.from_dict(index_dict)
            logger.info("Loaded inverted index from storage.")

        # Load web graph and PageRank scores
        web_graph = self.storage.load_web_graph()
        if web_graph:
            self.pagerank.load_graph(web_graph)
            logger.info("Loaded web graph from storage.")

            # Load PageRank scores
            self.pagerank_scores = self.storage.load_pagerank_scores()
            if not self.pagerank_scores:
                # Calculate PageRank if scores not available
                self.pagerank_scores = self.pagerank.calculate_pagerank()
                self.storage.save_pagerank_scores(self.pagerank_scores)

            logger.info(f"Loaded PageRank scores for {len(self.pagerank_scores)} URLs.")

    def index_documents(self, documents: Dict[str, Document]) -> None:
        """
        Index documents for search.

        Args:
            documents: Dictionary of URL -> Document
        """
        # Store documents
        self.documents.update(documents)
        self.storage.save_documents(documents)

        # Build inverted index
        self.inverted_index.build_index(self.documents)
        self.storage.save_inverted_index(self.inverted_index.to_dict())

        # Build web graph and calculate PageRank
        web_graph = self.pagerank.build_graph(self.documents)
        self.storage.save_web_graph(web_graph)

        self.pagerank_scores = self.pagerank.calculate_pagerank()
        self.storage.save_pagerank_scores(self.pagerank_scores)

    def search(
        self, query: str, max_results: int = 10
    ) -> Tuple[List[SearchResult], List[SearchResult]]:
        """
        Search for documents matching the query.

        Args:
            query: Search query
            max_results: Maximum number of results to return

        Returns:
            Tuple of (relevance_results, pagerank_results) - both lists of SearchResult
        """
        if not query:
            return [], []

        try:
            # Search using inverted index
            relevance_scores = self.inverted_index.search(query)

            # If no results or relevance_scores is None, return empty lists
            if not relevance_scores:
                logger.info(f"No results found for query: {query}")
                return [], []

            # Create results sorted by relevance
            relevance_results = []
            for url, score in sorted(
                relevance_scores.items(), key=lambda x: x[1], reverse=True
            )[:max_results]:
                if url in self.documents:
                    document = self.documents[url]
                    content_preview = self._get_content_preview(document, query)
                    relevance_results.append(
                        SearchResult(
                            url=url,
                            title=document.title or url,  # Ensure title is not None
                            content_preview=content_preview,
                            score=score,
                        )
                    )

            # Create results sorted by PageRank
            pagerank_results = []
            # Filter URLs to only those matching the query
            matching_urls = set(relevance_scores.keys())

            # Sort matching URLs by PageRank score
            ranked_urls = []
            for url in matching_urls:
                pagerank_score = self.pagerank_scores.get(url, 0.0)
                ranked_urls.append((url, pagerank_score))

            ranked_urls.sort(key=lambda x: x[1], reverse=True)

            # Create results
            for url, score in ranked_urls[:max_results]:
                if url in self.documents:
                    document = self.documents[url]
                    content_preview = self._get_content_preview(document, query)
                    pagerank_results.append(
                        SearchResult(
                            url=url,
                            title=document.title or url,  # Ensure title is not None
                            content_preview=content_preview,
                            score=score,
                        )
                    )

            return relevance_results, pagerank_results

        except Exception as e:
            logger.error(f"Error in search method for query '{query}': {str(e)}")
            # Return empty lists in case of error
            return [], []

    def _get_content_preview(
        self, document: Document, query: str, context_size: int = 100
    ) -> str:
        """
        Get a content preview with the query terms highlighted.

        Args:
            document: Document to get preview from
            query: Search query
            context_size: Number of characters of context to include

        Returns:
            Content preview with query terms
        """
        content = document.content_text.lower()
        query_terms = query.lower().split()

        # Try to find the first occurrence of any query term
        best_pos = -1
        best_term = ""

        for term in query_terms:
            pos = content.find(term)
            if pos != -1 and (best_pos == -1 or pos < best_pos):
                best_pos = pos
                best_term = term

        if best_pos == -1:
            # No match found, return the beginning of the content
            return document.content_text[:200] + "..."

        # Calculate the start and end positions for the preview
        start = max(0, best_pos - context_size)
        end = min(len(content), best_pos + len(best_term) + context_size)

        # Get the preview text
        preview = document.content_text[start:end]

        # Add ellipsis if needed
        if start > 0:
            preview = "..." + preview
        if end < len(document.content_text):
            preview = preview + "..."

        return preview

    def get_document(self, url: str) -> Optional[Document]:
        """
        Get a document by URL.

        Args:
            url: URL of the document

        Returns:
            Document if found, None otherwise
        """
        return self.documents.get(url)
