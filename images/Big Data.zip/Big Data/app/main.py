import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parent.parent))


from fastapi import FastAPI, Depends, Request, Query
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
import os
import logging
import uvicorn
from pathlib import Path
from fastapi.responses import RedirectResponse

from dotenv import load_dotenv

load_dotenv()


from app.api.endpoints import router as api_router, EndpointDependencies
from app.services.search_service import SearchService
from app.services.summary_service import SummaryService
from app.storage.hdfs_storage import HDFSStorage

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Search Engine API",
    description="API for a web search engine with inverted index and PageRank",
    version="1.0.0",
)


# Create services
storage = HDFSStorage()
search_service = SearchService(storage)
summary_service = SummaryService()


# Set up dependency injection
def get_dependencies():
    return EndpointDependencies(
        search_service=search_service, summary_service=summary_service
    )


# Include API router
app.include_router(api_router, prefix="/api")

# Set up static files
static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=static_dir), name="static")

# Set up templates
templates_dir = Path(__file__).parent.parent / "templates"
templates = Jinja2Templates(directory=templates_dir)


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    """Serve the search page."""
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/search")
async def search_redirect(query: str = Query(None)):
    """Redirect /search requests to /api/search."""
    url = f"/api/search?query={query}" if query else "/api/search"
    return RedirectResponse(url=url)


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}


if __name__ == "__main__":
    # Run the application
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=True)
