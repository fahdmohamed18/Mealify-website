from fastapi import APIRouter, HTTPException, Query, Depends
from typing import List, Dict, Any
import logging

from app.services.search_service import SearchService
from app.services.summary_service import SummaryService
from app.models.document import SearchResult, Document
from app.crawler.web_crawler import WebCrawler
from app.storage.hdfs_storage import HDFSStorage
from pydantic import BaseModel

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create router
router = APIRouter()


class EndpointDependencies:
    """Class to manage dependencies for endpoints."""

    def __init__(self, search_service: SearchService, summary_service: SummaryService):
        self.search_service = search_service
        self.summary_service = summary_service


class SummarizeRequest(BaseModel):
    urls: List[str]


def get_hdfs_storage() -> HDFSStorage:
    return HDFSStorage(...)  # Initialize with actual config if needed


def get_search_service(
    storage: HDFSStorage = Depends(get_hdfs_storage),
) -> SearchService:
    return SearchService(storage)


def get_summary_service() -> SummaryService:
    return SummaryService()


def get_endpoint_dependencies(
    search_service: SearchService = Depends(get_search_service),
    summary_service: SummaryService = Depends(get_summary_service),
) -> EndpointDependencies:
    return EndpointDependencies(search_service, summary_service)


@router.get("/search", response_model=Dict[str, Any])
async def search(
    query: str = Query(..., description="Search query"),
    max_results: int = Query(10, description="Maximum number of results"),
    summarize: bool = Query(False, description="Whether to generate summaries"),
    deps: EndpointDependencies = Depends(get_endpoint_dependencies),
):
    """
    Search for documents matching the query.

    Args:
        query: Search query
        max_results: Maximum number of results to return
        summarize: Whether to generate summaries

    Returns:
        Dict with relevance_results and pagerank_results
    """
    try:
        # Log the incoming search query
        logger.info(f"Processing search query: '{query}'")

        # Search for documents
        relevance_results, pagerank_results = deps.search_service.search(
            query, max_results
        )

        # Log the results count
        logger.info(
            f"Found {len(relevance_results)} relevance results and {len(pagerank_results)} pagerank results"
        )

        # Generate summaries if requested
        if summarize and (relevance_results or pagerank_results):
            try:
                # Limit to top 5 from each result set
                top_relevance = relevance_results[:5]
                top_pagerank = pagerank_results[:5]

                # Deduplicate
                seen_urls = set()
                unique_results = []

                for result in top_relevance + top_pagerank:
                    if result.url not in seen_urls:
                        seen_urls.add(result.url)
                        unique_results.append(result)

                # Generate summaries
                enhanced_results = await deps.summary_service.enhance_search_results(
                    unique_results
                )

                # Update results with summaries
                summary_map = {
                    result.url: result.summary
                    for result in enhanced_results
                    if result.summary
                }

                for result in relevance_results + pagerank_results:
                    if result.url in summary_map:
                        result.summary = summary_map[result.url]
            except Exception as e:
                # If summarization fails, log it but continue with results
                logger.error(f"Error generating summaries: {str(e)}")

        # Convert results to dictionaries
        relevance_dict_results = []
        for result in relevance_results:
            try:
                relevance_dict_results.append(result.dict())
            except Exception as e:
                logger.error(f"Error converting relevance result to dict: {str(e)}")

        pagerank_dict_results = []
        for result in pagerank_results:
            try:
                pagerank_dict_results.append(result.dict())
            except Exception as e:
                logger.error(f"Error converting pagerank result to dict: {str(e)}")

        return {
            "relevance_results": relevance_dict_results,
            "pagerank_results": pagerank_dict_results,
        }

    except Exception as e:
        logger.error(f"Error processing search query '{query}': {str(e)}")
        return {
            "relevance_results": [],
            "pagerank_results": [],
            "error": f"Search error: {str(e)}",
        }


@router.get("/document/{url:path}", response_model=Dict[str, Any])
async def get_document(
    url: str, deps: EndpointDependencies = Depends(get_endpoint_dependencies)
):
    """
    Get a document by URL.

    Args:
        url: URL of the document

    Returns:
        Document data
    """
    try:
        document = deps.search_service.get_document(url)

        if not document:
            raise HTTPException(status_code=404, detail=f"Document not found: {url}")

        return {
            "url": document.url,
            "title": document.title,
            "content": document.content,
            "content_text": document.content_text,
            "last_crawled": document.last_crawled,
            "outgoing_links": document.outgoing_links,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving document '{url}': {str(e)}")
        raise HTTPException(
            status_code=500, detail=f"Error retrieving document: {str(e)}"
        )


@router.post("/crawl", response_model=Dict[str, Any])
async def crawl(
    start_urls: List[str],
    max_pages: int = Query(50, description="Maximum number of pages to crawl"),
    deps: EndpointDependencies = Depends(get_endpoint_dependencies),
):
    """
    Crawl web pages starting from the provided URLs.

    Args:
        start_urls: URLs to start crawling from
        max_pages: Maximum number of pages to crawl

    Returns:
        Status of the crawl
    """
    try:
        # Create crawler
        crawler = WebCrawler(start_urls, max_pages=max_pages)

        # Crawl pages
        documents = crawler.crawl()

        # Index documents
        deps.search_service.index_documents(documents)

        return {
            "status": "success",
            "message": f"Crawled {len(documents)} documents",
            "crawled_urls": list(documents.keys()),
        }

    except Exception as e:
        logger.error(f"Error crawling pages: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error crawling pages: {str(e)}")


@router.post("/summarize", response_model=Dict[str, Any])
async def summarize_urls(
    request: SummarizeRequest,
    deps: EndpointDependencies = Depends(get_endpoint_dependencies),
):
    """
    Generate summaries for multiple documents.

    Args:
        request: Request with URLs to summarize

    Returns:
        Summaries of the documents
    """
    try:
        urls = request.urls
        if not urls:
            raise HTTPException(status_code=400, detail="No URLs provided")

        summaries = []
        for url in urls:
            document = deps.search_service.get_document(url)
            if document:
                # Generate summary
                summary = deps.summary_service.summarize_document(document)
                summaries.append(
                    {
                        "url": document.url,
                        "title": document.title,
                        "summary": summary or "No summary available",
                    }
                )

        return {"summaries": summaries}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error summarizing documents: {str(e)}")
        raise HTTPException(
            status_code=500, detail=f"Error summarizing documents: {str(e)}"
        )
