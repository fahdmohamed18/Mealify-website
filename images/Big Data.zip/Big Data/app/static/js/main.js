document.addEventListener("DOMContentLoaded", () => {
  // Existing DOM elements
  const searchInput = document.getElementById("search-input");
  const searchButton = document.getElementById("search-button");
  const resultsDiv = document.getElementById("search-results");
  const resultsCountDiv = document.getElementById("results-count");
  const summarizeButton = document.getElementById("summarize-button");
  const loadingOverlay = document.getElementById("loading-overlay");
  const loadingText = document.getElementById("loading-text");
  const errorMessageDiv = document.getElementById("error-message");
  const rankingOptions = document.querySelectorAll('input[name="ranking"]');

  // New DOM element for dark mode
  const themeToggle = document.getElementById("theme-toggle");

  // State variables
  let currentQuery = "";
  let relevanceResults = [];
  let pagerankResults = [];
  let currentSummaries = new Map(); // Store summaries for all URLs
  let top5DisplayedUrls = [];
  let isSearching = false;
  let isSummarizing = false;

  // Theme Management
  function loadTheme() {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
      document.body.classList.add("dark-theme");
      themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    } else {
      document.body.classList.remove("dark-theme");
      themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    }
  }

  function toggleTheme() {
    if (document.body.classList.contains("dark-theme")) {
      document.body.classList.remove("dark-theme");
      localStorage.setItem("theme", "light");
      themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
    } else {
      document.body.classList.add("dark-theme");
      localStorage.setItem("theme", "dark");
      themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
  }

  // Initialize theme from local storage
  loadTheme();

  // Theme toggle event listener
  themeToggle.addEventListener("click", toggleTheme);

  // Helper functions
  function showLoading(message = "Searching...") {
    loadingText.textContent = message;
    loadingOverlay.style.display = "flex";
    isSearching = true;
  }

  function hideLoading() {
    loadingOverlay.style.display = "none";
    isSearching = false;
  }

  function displayError(message) {
    errorMessageDiv.textContent = message;
    errorMessageDiv.style.display = "block";
  }

  function clearError() {
    errorMessageDiv.style.display = "none";
    errorMessageDiv.textContent = "";
  }

  function clearResultsDisplay() {
    resultsDiv.innerHTML = `
      <div class="empty-state">
        <i class="fas fa-search empty-icon"></i>
        <p class="empty-text">Search for something to see results</p>
      </div>
    `;
    resultsCountDiv.textContent = "Enter a query to see results";
    summarizeButton.disabled = true;
    currentSummaries.clear();
  }

  function getSelectedRanking() {
    const selected = document.querySelector('input[name="ranking"]:checked');
    return selected ? selected.value : "relevance";
  }

  // Display search results based on selected ranking option
  function displayRankedResults() {
    clearError();
    const ranking = getSelectedRanking();
    const resultsToDisplay =
      ranking === "pagerank" ? pagerankResults : relevanceResults;

    resultsDiv.innerHTML = "";

    if (resultsToDisplay.length > 0) {
      resultsCountDiv.textContent = `${resultsToDisplay.length} results found (Sorted by ${ranking})`;

      resultsToDisplay.forEach((item, index) => {
        const resultItem = document.createElement("div");
        resultItem.className = "result-item fade-in";
        resultItem.id = `result-item-${index}`;
        resultItem.style.animationDelay = `${index * 0.1}s`;

        const titleLink = document.createElement("a");
        titleLink.className = "result-title";
        titleLink.href = item.url;
        titleLink.textContent = item.title || item.url;
        titleLink.target = "_blank";

        const urlSpan = document.createElement("div");
        urlSpan.className = "result-url";
        urlSpan.textContent = item.url;

        const scoreSpan = document.createElement("div");
        scoreSpan.className = "result-score";
        scoreSpan.textContent = `Score: ${item.score.toFixed(6)}`;

        resultItem.appendChild(titleLink);
        resultItem.appendChild(urlSpan);
        resultItem.appendChild(scoreSpan);

        // Add summary container for top 5 results of any ranking
        if (index < 5) {
          const summaryDiv = document.createElement("div");
          summaryDiv.className = "result-summary";
          summaryDiv.id = `summary-${item.url.replace(/[^a-z0-9]/gi, "_")}`;

          // Display existing summary if available
          if (currentSummaries.has(item.url)) {
            const summary = currentSummaries.get(item.url);
            summaryDiv.innerHTML = `<p>${summary}</p>`;
            summaryDiv.style.display = "block";
          } else {
            summaryDiv.style.display = "none";
          }

          resultItem.appendChild(summaryDiv);
        }

        resultsDiv.appendChild(resultItem);
      });
    } else {
      resultsDiv.innerHTML = `
        <div class="empty-state">
          <i class="fas fa-search-minus empty-icon"></i>
          <p class="empty-text">No results found for this query</p>
        </div>
      `;
      resultsCountDiv.textContent = "0 results found";
    }

    // Update top 5 URLs based on selected ranking
    const topResults = resultsToDisplay.slice(0, 5);
    top5DisplayedUrls = topResults.map((item) => item.url);

    // Enable summarize button if we have results and not all top 5 have summaries yet
    const allSummarized =
      top5DisplayedUrls.length > 0 &&
      top5DisplayedUrls.every((url) => currentSummaries.has(url));
    summarizeButton.disabled =
      top5DisplayedUrls.length === 0 || isSummarizing || allSummarized;
  }

  // Search function that calls the API
  async function handleSearch() {
    const query = searchInput.value.trim();

    if (!query) {
      displayError("Please enter a search query.");
      clearResultsDisplay();
      return;
    }

    if (isSearching) return;

    clearError();
    showLoading("Searching...");
    currentQuery = query;
    currentSummaries.clear(); // Clear summaries when performing a new search

    try {
      const response = await fetch(
        `/api/search?query=${encodeURIComponent(query)}&summarize=false`
      );

      if (!response.ok) {
        let errorMsg = `Search failed: ${response.status}`;
        try {
          const errorData = await response.json();
          errorMsg = errorData.detail || errorMsg;
        } catch (e) {}
        throw new Error(errorMsg);
      }

      const data = await response.json();
      relevanceResults = data.relevance_results || [];
      pagerankResults = data.pagerank_results || [];

      relevanceResults.forEach((r) => (r.title = r.title || r.url));
      pagerankResults.forEach((r) => (r.title = r.title || r.url));

      displayRankedResults();
    } catch (error) {
      console.error("Search Error:", error);
      displayError(`Search error: ${error.message}`);
      clearResultsDisplay();
      relevanceResults = [];
      pagerankResults = [];
    } finally {
      hideLoading();
    }
  }

  // Summarize top 5 search results
  async function handleSummarize() {
    if (top5DisplayedUrls.length === 0 || isSummarizing) return;

    // Filter URLs that don't have summaries yet
    const urlsToSummarize = top5DisplayedUrls.filter(
      (url) => !currentSummaries.has(url)
    );

    if (urlsToSummarize.length === 0) {
      return; // All URLs already have summaries
    }

    isSummarizing = true;
    clearError();

    summarizeButton.disabled = true;
    summarizeButton.innerHTML =
      '<i class="fas fa-spinner fa-spin"></i> Summarizing...';

    // Show loading states for summaries that need to be generated
    urlsToSummarize.forEach((url) => {
      const summaryDiv = document.getElementById(
        `summary-${url.replace(/[^a-z0-9]/gi, "_")}`
      );
      if (summaryDiv) {
        summaryDiv.innerHTML = `
          <div class="summary-loading">
            <i class="fas fa-spinner fa-spin"></i>
            <span>Generating summary...</span>
          </div>
        `;
        summaryDiv.style.display = "block";
      }
    });

    try {
      const response = await fetch("/api/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ urls: urlsToSummarize }),
      });

      if (!response.ok) {
        let errorMsg = `Summarization failed: ${response.status}`;
        try {
          const errorData = await response.json();
          errorMsg = errorData.detail || errorMsg;
        } catch (e) {}
        throw new Error(errorMsg);
      }

      const data = await response.json();

      // Update summaries in our state and in the UI
      data.summaries.forEach((item) => {
        const url = item.url;
        const summary =
          item.summary || "Summary not available for this result.";

        // Store summary in our state
        currentSummaries.set(url, summary);

        // Update UI
        const summaryDiv = document.getElementById(
          `summary-${url.replace(/[^a-z0-9]/gi, "_")}`
        );
        if (summaryDiv) {
          summaryDiv.innerHTML = `<p>${summary}</p>`;
          summaryDiv.style.display = "block";
        }
      });
    } catch (error) {
      console.error("Summarization Error:", error);
      displayError(`Summarization error: ${error.message}`);

      // Show error states for summaries being generated
      urlsToSummarize.forEach((url) => {
        const summaryDiv = document.getElementById(
          `summary-${url.replace(/[^a-z0-9]/gi, "_")}`
        );
        if (summaryDiv) {
          summaryDiv.innerHTML = `<p><i>Error loading summary.</i></p>`;
        }
      });
    } finally {
      isSummarizing = false;

      // Only enable button if there are URLs without summaries
      const remainingUrls = top5DisplayedUrls.filter(
        (url) => !currentSummaries.has(url)
      );
      summarizeButton.disabled = remainingUrls.length === 0;
      summarizeButton.innerHTML =
        '<i class="fas fa-robot"></i> Summarize With AI';
    }
  }

  // Handle changes to the ranking option
  function handleRankingChange() {
    if (relevanceResults.length > 0 || pagerankResults.length > 0) {
      displayRankedResults();
    }
  }

  // Event listeners
  searchButton.addEventListener("click", handleSearch);
  searchInput.addEventListener("keypress", (event) => {
    if (event.key === "Enter") handleSearch();
  });
  summarizeButton.addEventListener("click", handleSummarize);
  rankingOptions.forEach((radio) =>
    radio.addEventListener("change", handleRankingChange)
  );

  // Initialize UI
  searchInput.focus();
  clearResultsDisplay();
});
