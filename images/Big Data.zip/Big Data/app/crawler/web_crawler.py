import requests
from bs4 import BeautifulSoup
import logging
from urllib.parse import urljoin, urlparse
from typing import List, Set, Dict, Optional
from datetime import datetime
import time
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from app.models.document import Document
from app.storage.hdfs_storage import HDFSStorage
from app.indexing.inverted_index import InvertedIndex
from app.indexing.pagerank import PageRank

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class WebCrawler:
    """Web crawler to fetch and parse web pages."""

    def __init__(
        self,
        base_urls: List[str],
        max_pages: int = 100,
        delay: float = 1.0,
        storage: Optional[HDFSStorage] = None,
    ):
        self.base_urls = base_urls
        self.max_pages = max_pages
        self.delay = delay
        self.visited_urls: Set[str] = set()
        self.documents: Dict[str, Document] = {}
        self.storage = storage or HDFSStorage()

    def is_valid_url(self, url: str) -> bool:
        parsed = urlparse(url)
        return bool(parsed.netloc) and bool(parsed.scheme)

    def get_links(self, soup: BeautifulSoup, base_url: str) -> List[str]:
        links = []
        for link in soup.find_all("a", href=True):
            href = link["href"]
            absolute_url = urljoin(base_url, href)
            absolute_url = absolute_url.split("#")[0]

            # Example: Only include article URLs that contain "/story/"
            ARTICLE_KEYWORDS = ["/story/", "/article/", "/news/", "/blog/"]
            if self.is_valid_url(absolute_url) and any(
                k in absolute_url.lower() for k in ARTICLE_KEYWORDS
            ):

                if absolute_url not in links:
                    links.append(absolute_url)
        return links

    def fetch_page(self, url: str) -> Optional[Document]:
        try:
            response = requests.get(
                url, headers={"User-Agent": "SearchEngineBot/1.0"}, timeout=10
            )
            response.raise_for_status()
            soup = BeautifulSoup(response.content, "lxml")
            title = soup.title.string.strip() if soup.title else url
            content_text = soup.get_text(separator=" ", strip=True)
            outgoing_links = self.get_links(soup, url)

            document = Document(
                url=url,
                title=title,
                content=str(soup),
                content_text=content_text,
                last_crawled=datetime.now(),
                outgoing_links=outgoing_links,
            )
            return document

        except Exception as e:
            logger.error(f"Error fetching {url}: {str(e)}")
            return None

    def save_document(self, document: Document) -> None:
        self.storage.save_document(document)

    def crawl(self) -> Dict[str, Document]:
        urls_to_visit = self.base_urls.copy()

        while urls_to_visit and len(self.visited_urls) < self.max_pages:
            url = urls_to_visit.pop(0)
            if url in self.visited_urls:
                continue

            logger.info(f"Crawling: {url}")
            self.visited_urls.add(url)
            document = self.fetch_page(url)

            if not document:
                continue

            self.documents[url] = document
            self.save_document(document)
            logger.info(f"Document saved for URL: {url}")

            for link in document.outgoing_links:
                if link not in self.visited_urls and link not in urls_to_visit:
                    urls_to_visit.append(link)

            time.sleep(self.delay + random.uniform(0, 0.5))

        logger.info(f"Crawl completed. Visited {len(self.visited_urls)} pages.")
        return self.documents


if __name__ == "__main__":
    # Step 1: Crawl web pages
    base_urls = [
        "https://www.youm7.com",
    ]
    storage = HDFSStorage()
    crawler = WebCrawler(base_urls=base_urls, max_pages=12, delay=2.0, storage=storage)
    documents = crawler.crawl()

    # Step 2: Build PageRank
    pagerank = PageRank()
    web_graph = pagerank.build_graph(documents)
    scores = pagerank.calculate_pagerank()
    ranked_urls = pagerank.get_ranked_urls()

    # Step 3: Save PageRank data
    storage.save_web_graph(web_graph)
    storage.save_pagerank_scores(scores)

    print("\nTop Ranked Pages:")
    for url in ranked_urls[:5]:
        print(f"{url} - PageRank Score: {scores.get(url):.5f}")

    # Step 4: Build and save Inverted Index
    index = InvertedIndex()
    index.build_index(documents)
    storage.save_inverted_index(index.to_dict())

    print("\nInverted Index Sample Terms:")
    for term in list(index.index.keys())[:5]:
        print(f"Term: {term} -> Docs: {list(index.index[term].keys())}")
