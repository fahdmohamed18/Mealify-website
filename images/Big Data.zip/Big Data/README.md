# Search Engine Project Structure

```
search_engine/
│
├── app/
│   ├── __init__.py
│   ├── main.py               # FastAPI application entry point
│   ├── crawler/
│   │   ├── __init__.py
│   │   └── web_crawler.py    # Web scraping functionality
│   │
│   ├── indexing/
│   │   ├── __init__.py
│   │   ├── inverted_index.py # Inverted index implementation
│   │   └── pagerank.py       # PageRank implementation
│   │
│   ├── storage/
│   │   ├── __init__.py
│   │   └── hdfs_storage.py   # HDFS storage functionality
│   │
│   ├── models/
│   │   ├── __init__.py
│   │   └── document.py       # Document data models
│   │
│   ├── services/
│   │   ├── __init__.py
│   │   ├── search_service.py # Core search functionality
│   │   └── summary_service.py # LLM integration for summaries
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   └── endpoints.py      # API endpoints
│   │
│   └── static/               # Static files
│       ├── css/
│       │   └── styles.css
│       └── js/
│           └── main.js
│
├── templates/
│   └── index.html            # Frontend HTML template
│
├── requirements.txt          # Project dependencies
└── README.md                 # Project documentation
```

## Technology Stack:

1. **Backend**: FastAPI, Python
2. **Storage**: HDFS (with PyArrow/hdfs)
3. **Frontend**: HTML5, CSS3, JavaScript
4. **AI Integration**: GPT API
5. **Web Scraping**: BeautifulSoup, Requests

## Implementation Approach:

1. Set up the FastAPI application structure
2. Implement web crawler with BeautifulSoup
3. Create HDFS storage connector
4. Implement inverted index for search functionality
5. Implement PageRank algorithm for ranking results
6. Build search service that combines inverted index and PageRank
7. Integrate GPT for summarization
8. Create API endpoints for searching and summarization
9. Build responsive frontend with search capabilities
10. Implement term highlighting feature when displaying results
